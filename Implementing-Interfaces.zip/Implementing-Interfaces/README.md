# Simple TypeScript Project

### To start the development mode:

```
npm run dev
```

This command will run the TS compiler in watch mode and nodemon.

### To stop the development mode:

1. Focus the terminal window where you started the app
2. Press `CTRL` + `C`

This should kill the process running the development mode.
